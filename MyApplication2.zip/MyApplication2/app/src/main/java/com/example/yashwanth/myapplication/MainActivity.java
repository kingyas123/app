package com.example.yashwanth.myapplication;

import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.nfc.Tag;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.*;
import android.widget.*;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;



import java.io.*;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;

import static java.lang.Boolean.FALSE;
import static java.lang.Boolean.TRUE;

import java.util.regex.*;
import java.util.Scanner;



public class MainActivity extends AppCompatActivity {
    Button b1;
    TextView t1;
    EditText e1;
    String data,Name;
    static Boolean t;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_main);

        t=isNetworkAvailable();
        if(t==TRUE)
            Toast.makeText(getApplicationContext(),"internet connected", Toast.LENGTH_LONG).show();
        else
            Toast.makeText(getApplicationContext(),"internet not connected", Toast.LENGTH_LONG).show();
        Spinner spinner = (Spinner) findViewById(R.id.spinner);
// Create an ArrayAdapter using the string array and a default spinner layout
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.planets_array, android.R.layout.simple_spinner_item);
// Specify the layout to use when the list of choices appears
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
// Apply the adapter to the spinner
        spinner.setAdapter(adapter);

    }

    public static boolean isValid(String s)//VALIDATION
    {
        Pattern p = Pattern.compile("15131A05[0-9|A-Z][0-9]|16135A05[0-9|A-Z][0-9]");
        Matcher m = p.matcher(s);
        return (m.find() && m.group().equals(s));
    }




    public boolean isNetworkAvailable()//internet checking {
        ConnectivityManager cm = (ConnectivityManager)
                getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo networkInfo = cm.getActiveNetworkInfo();
        // if no network is available networkInfo will be null
        // otherwise check if we are connected
        if (networkInfo != null && networkInfo.isConnected()) {
            return true;
        }
        return false;
    }



    public  void  GetText(View v)  throws  UnsupportedEncodingException
    {

        FirebaseInstanceId.getInstance().getInstanceId()
                .addOnCompleteListener(new OnCompleteListener<InstanceIdResult>() {
                    @Override
                    public void onComplete(@NonNull Task<InstanceIdResult> task) {
                        if (!task.isSuccessful()) {
                            Log.w("MainActivity", "getInstanceId failed", task.getException());
                            return;
                        }

                        // Get new Instance ID token
                        String token = task.getResult().getToken().toString();

                        // Log and toast
                        String msg = getString(R.string.Token,token);
                        Log.d("Token generation", msg);
                        Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
                        sendData(token);
                    }});
    }

    public void sendData(String token){//SENDING DATA TO SERVER
        OkHttpClient client = new OkHttpClient();
        e1=(EditText)findViewById(R.id.editText);
        Spinner spinner = (Spinner) findViewById(R.id.spinner);
        spinner.setOnItemSelectedListener(new Spin());
        String s=e1.getText().toString();
        t=isValid(s);
        if(t)
        {
            String spin1 = String.valueOf(spinner.getSelectedItem());
           t=isSec(s,spin1);
            if(t) {
                Log.d("Token1 generation", token);
                FormBody.Builder formBody = new FormBody.Builder()
                        .add("token", token);
                formBody.add("s", s);
                formBody.add("spin", spin1);
                RequestBody formbody = formBody.build();
                Request request = new Request.Builder()
                        .url("http://192.168.1.7/App/data.php")
                        .post(formbody)
                        .build();
                client.newCall(request).enqueue(new Callback() {
                    @Override
                    public void onFailure(Call call, IOException e) {
                        Log.d("error", "error occured" + e);
                    }

                    @Override
                    public void onResponse(Call call, Response response) throws IOException {
                        Log.i("response", response.body().string());
                    }

                });
                startActivity(new Intent(MainActivity.this, Main3Activity.class));
            }
            else
            {
                Toast.makeText(MainActivity.this, "INVALID SECTION", Toast.LENGTH_SHORT).show();
            }


        }
        else
        {
            Toast.makeText(MainActivity.this, "INVALID ROLL NUMBER", Toast.LENGTH_SHORT).show();
        }

    }

    private Boolean isSec(String s, String spin1) {//SELCTED SECTION AND ROLLNO ARE IN THE SAME SECCTION
        if(isValidCse1(s)&&spin1.equals("cse1"))
            return true;
        else if(isValidCse2(s)&&spin1.equals("cse2"))
            return  true;
        else if(isValidCse3(s)&&spin1.equals("cse3"))
            return true;
        else if(isValidCse4(s)&&spin1.equals("cse4"))
            return true;
        return false;
    }

    private boolean isValidCse4(String s) {//validation for cse4
        Pattern p = Pattern.compile("15131A05[I-M][0-9]|16135A055[0-9]|15131A05N[0-4]|15131A05H[6-9]");
        Matcher m = p.matcher(s);
        return (m.find() && m.group().equals(s));
    }

    private boolean isValidCse3(String s) {//validation for cse3
        Pattern p = Pattern.compile("15131A05[C-G][0-9]|16135A053[5-9]|16135A054[0-9]|15131A05B[7-9]|15131A05H[0-5]");
        Matcher m = p.matcher(s);
        return (m.find() && m.group().equals(s));
    }

    private boolean isValidCse2(String s) {//validation for cse2
        Pattern p = Pattern.compile("15131A0559|16135A052[0-9]|16135A053[0-5]|15131A05[6-9|A][0-9]|15131A05B[0-6]|16135A051[6-9]");
        Matcher m = p.matcher(s);
        return (m.find() && m.group().equals(s));
    }

    private boolean isValidCse1(String s) {
        Pattern p = Pattern.compile("15131A05[0-4][0-9]|16135A050[0-9]|16135A051[0-5]|15131A055[0-8]");
        Matcher m = p.matcher(s);
        return (m.find() && m.group().equals(s));
    }


}

