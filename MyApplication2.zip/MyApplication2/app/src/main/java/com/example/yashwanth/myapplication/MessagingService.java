package com.example.yashwanth.myapplication;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.os.Build;
import android.service.notification.StatusBarNotification;
import android.support.annotation.NonNull;
import android.support.v4.app.NotificationCompat;
import android.util.Log;
import android.widget.TextView;
import android.widget.Toast;

import com.example.yashwanth.myapplication.MainActivity;
import com.example.yashwanth.myapplication.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.iid.InstanceIdResult;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;

import java.io.IOException;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.FormBody;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.RequestBody;
import okhttp3.Response;


public class MessagingService extends FirebaseMessagingService {
    public String token;
    public String title;
    public String message;

    @Override
    public void onNewToken(String token) {

        super.onNewToken(token);
        this.token = token;
        Log.d("token", "onNewToken:" + token);

        // sendData(token);

    }

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);

        title = remoteMessage.getNotification().getTitle();
        message = remoteMessage.getNotification().getBody();
        Log.d("Service", "From" + remoteMessage.getData());
        Toast.makeText(new Main3Activity(), message, Toast.LENGTH_LONG).show();
        String h = title + " " + message;
        Intent i = new Intent(this, Main3Activity.class);
        Notification.Builder mb = new Notification.Builder(this);
        mb.setContentTitle(title);
        mb.setContentText(message);
        PendingIntent p = PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_UPDATE_CURRENT);
        mb.setContentIntent(p);
        mb.setPriority(Notification.PRIORITY_HIGH);
        mb.setWhen(System.currentTimeMillis());

        NotificationManager n = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);

        n.notify(0, mb.build());
    }
   /*private  Intent getNotificationIntent()
    {
        Intent intent =new Intent(this,Main3Activity.class);
        intent.setFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP|Intent.FLAG_ACTIVITY_SINGLE_TOP);
        return intent;
    }*/
    /*public void processIntentAction(Intent intent)
    {
        if(intent.getAction()!=null)
        {
            switch (intent.getAction())
            {
                case NO_ACTION:
                    Toast.makeText(this,"no",Toast.LENGTH_SHORT).show();
                    break;
                case YES_ACTION :
                    Toast.makeText(this,"yes",Toast.LENGTH_SHORT).show();
                    break;
            }
        }

    }*/
}
